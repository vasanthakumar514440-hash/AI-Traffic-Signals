## 🚦 AI Traffic Signals – Nagpur

### Case Study Overview

Nagpur city launched a pilot project deploying AI-driven traffic signals at three major urban junctions. This initiative aims to optimize traffic flow and reduce congestion using artificial intelligence.

### Reference

[Times of India - AI Traffic Signals in Nagpur](https://timesofindia.indiatimes.com/city/nagpur/ai-driven-traffic-signals-go-live-at-3-junctions-pilot-rollout-by-june-15/articleshow/121658302.cms)

---

